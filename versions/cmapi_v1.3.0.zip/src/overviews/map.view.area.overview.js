cmapi.overview["map.view.area"] = {
  "title": "map.view.area namespace",
  "sections": [{
    "title": "Overview",
    "paragraphs": [
      "Namespace for those messages and channels that are associated with the map view area (i.e., what portion of the map view the end user is interested in)."
    ]
  }]
};
