cmapi.overview["map.feature.plot.formats.overview"] = {
  "title": "Data formats supported in map.feature channels",
  "sections": [{
    "title": "Overview",
    "paragraphs": [
      "This sections lists the data formats supported in the map.feature channels as well as implementation details for each format."
    ]
  }]
};
