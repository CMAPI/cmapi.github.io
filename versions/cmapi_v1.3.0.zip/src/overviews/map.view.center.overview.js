cmapi.overview["map.view.center.overview"] = {
  "title": "map.view.center namespace ",
  "sections": [{
    "title": "Overview",
    "paragraphs": [
      "Namespace for map.view operations that center on entites such as an overlay, feature, or area"
    ]
  }]
};
