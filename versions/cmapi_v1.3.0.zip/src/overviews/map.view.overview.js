cmapi.overview["map.view.overview"] = {
  "title": "map.view namespace",
  "sections": [{
    "title": "Overview",
    "paragraphs": [
      "Namespace for those messages and channels that are associated with manipulating the map view (i.e., what portion of the map is displayed to the end user)."
    ]
  }]
};
