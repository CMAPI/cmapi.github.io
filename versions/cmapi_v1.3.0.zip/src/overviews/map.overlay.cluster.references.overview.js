cmapi.overview["map.overlay.cluster.references"] = {
	"title" : "Clustering: References",
	"sections": [{
		"title": " ",
		"paragraphs": [
			"Too Many Markers by Luke Mahe and Chris Broadfoot  -  <a href=\"https://developers.google.com/maps/articles/toomanymarkers\" target=\"_blank\" >https://developers.google.com/maps/articles/toomanymarkers</a>"
		]
	}]
};