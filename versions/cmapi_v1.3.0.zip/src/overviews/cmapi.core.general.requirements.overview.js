cmapi.overview["cmapi.core.general.requirements.overview"] = {
  "title": "CMAPI Core General Requirements",
  "sections": [{
    "title": "",
    "paragraphs": [
      "This section contains general guidance that applies to CMAPI behavior and documentation "
    ]
  }]
};
