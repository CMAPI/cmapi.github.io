cmapi.channel["map.overlay.remove"] = {
  schema: {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "map.overlay.remove",
    "properties": {
      "overlayId": {
        "type": "string"
      }
    },
    "required": []
  }
};
