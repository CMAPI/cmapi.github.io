cmapi.channel["map.overlay.cluster.activate"] = {
  schema: {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "map.overlay.cluster.activate",
    "properties": {
      "overlayId": {
        "type": "string"
      }
    },
    "required": []
  }
};
