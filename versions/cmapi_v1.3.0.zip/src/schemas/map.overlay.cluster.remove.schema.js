cmapi.channel["map.overlay.cluster.remove"] = {
  schema: {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "map.overlay.cluster.remove",
    "properties": {
      "overlayId": {
        "type": "string"
      }
    },
    "required": []
  }
};
