cmapi.channel["map.overlay.show"] = {
  schema: {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "map.overlay.show",
    "properties": {
      "overlayId": {
        "type": "string"
      }
    },
    "required": []
  }
};
