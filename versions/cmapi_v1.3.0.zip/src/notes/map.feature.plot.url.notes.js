cmapi.channel["map.feature.plot.url"].notes = [
    "For version 1.1.0 of the API, featureName was changed to name for consistency with feature.plot.  In order to maintain backwards compatibility with version 1.0.* of the API, it is suggested that developers on the receiving side of these messages should look for the old featureName if name is not found in the message."
  ];