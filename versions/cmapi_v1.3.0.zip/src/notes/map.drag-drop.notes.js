cmapi.channel["map.drag-drop"].notes = [
    "Although marker, feature, and featureUrl are optional, one MUST be present.",
  "If marker is included, the marker will be placed at the location of the drop.",
  "Feature and featureUrl data will be placed at their natural location (equivalent to being loaded using map.feature.plot or map.feature.plot.url message)."
  ];