cmapi.channel["map.status.format"].examples = [{
  "title": "Send view status with all properties",
  "description": "",
  "valid": true,
  "payload": {
    "formats": [
      "kml",
      "geojson",
      "wms"
    ]
  }
}, {
  "title": "Send view status with all properties",
  "description": "",
  "valid": true,
  "payload": {
    "formats": [
      "kml",
      "geojson",
      "wms",
      "czml"
    ]
  }
}, {
  "title": "Send view status with all properties",
  "description": "",
  "valid": false,
  "payload": {}
}];
