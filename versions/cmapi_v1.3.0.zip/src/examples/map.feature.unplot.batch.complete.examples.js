cmapi.channel["map.feature.unplot.batch.complete"].examples = [{
  "title": "Unplot batch complete",
  "description": "",
  "valid": true,
  "payload": {"features": [
	{
		"featureId": "example.mapWidget.1",
		"overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1"
	},{
		"featureId": "example.mapWidget.2",
		"overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1"
	},{
		"featureId": "example.mapWidget.3",
		"overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1"
	},{
		"featureId": "example.mapWidget.4",
		"overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1"
	}]
}}];
