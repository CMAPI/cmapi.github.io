cmapi.channel["map.overlay.cluster.deactivate"].examples = [{
  "title": "Deactivate overlay cluster rule example",
  "description": "",
  "valid": true,
  "payload": {
    "overlayId": "BattlePlan2"
  }
}];