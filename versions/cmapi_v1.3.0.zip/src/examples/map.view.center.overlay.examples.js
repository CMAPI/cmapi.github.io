cmapi.channel["map.view.center.overlay"].examples = [{
  "title": "Center on an Overlay",
  "description": "Center the map on a particular overlay",
  "valid": true,
  "payload": {
    "overlayId": "2tyjhp-23idk38-rml389k6kd-29-flsow2c"
  }
}];
