cmapi.channel["map.feature.deselected.batch.complete"].examples = [{
  "title": "de-select batch complete",
  "description": "",
  "valid": true,
  "payload": {"features": [
	{
		"overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1",
		"featureId": "example.mapWidget.1",
		"deSelectedName": "World Trade Center",
		"deSelectedId":""
	},{
		"overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1",
		"featureId": "example.mapWidget.2",
		"deSelectedName": "911 Memorial Museum",
		"deSelectedId":""
	},{
		"overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1",
		"featureId": "example.mapWidget.3",
		"deSelectedName": "Millenium Hilton",
		"deSelectedId":""
	},{
		"overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1",
		"featureId": "example.mapWidget.4",
		"deSelectedName": "911 Tribute Center",
		"deSelectedId":""
	}],
 
}}];
