cmapi.channel["map.overlay.cluster.remove"].examples = [{
  "title": "Remove overlay cluster rule example",
  "description": "",
  "valid": true,
  "payload": {
    "overlayId": "BattlePlan2"
  }
}];