cmapi.channel["map.view.center.overlay.complete"].examples = [{
  "title": "map.message.complete details object for Center on an Overlay",
  "description": "Center the map on a particular overlay",
  "valid": true,
  "payload": {
    "overlayId": "2tyjhp-23idk38-rml389k6kd-29-flsow2c",
	"zoom":"9500"
  }
}];
