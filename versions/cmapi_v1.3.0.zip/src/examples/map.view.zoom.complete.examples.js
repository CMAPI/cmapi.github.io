cmapi.channel["map.view.zoom.complete"].examples = [{
  "title": "Zoomto a range",
  "description": "The range the map was zoomed to",
  "valid": true,
  "payload": {
    "range": 100000
  }
}];
