cmapi.channel["map.feature.unplot.complete"].examples = [{
  "title": "Unplot a feature",
  "description": "Remove an existing feature from the map",
  "valid": true,
  "payload": {
    "overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1",
    "featureId": "example.mapWidget.2"
  }
}];
