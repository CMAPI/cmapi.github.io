cmapi.channel["map.overlay.remove.complete"].examples = [
    {
    "title": "map.message.complete details object for map.overlay.remove message",
    "description" : "Remove entire overlay from the map.",
    "valid": true,
    "payload": {
        "overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1"
        }
    }
];



