cmapi.channel["map.feature.update.complete"].examples = [{
  "title": "map.message.complete details object for map.feature.update message",
  "description": "",
  "valid": true,
  "payload": {
    "overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1",
    "featureId": "example.mapWidget.2",
    "name": "New Name",
	"newOverlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1"
  }
}];
