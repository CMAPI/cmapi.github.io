cmapi.channel["map.status.initialization"].examples = [{
  "title": "Initialization status",
  "description": "",
  "valid": true,
  "payload": {
    "status": "mapswapinprogress"
  }
}];