var cmapi = window.cmapi || {};
cmapi.lang = {
	MESSAGE_VALIDATION_FAILURE : "Invalid CMAPI Payload:",
	MESSAGE_VALIDATION_SUCCESS : "Valid CMAPI Payload",
	OPTIONAL : "optional",
	REQUIRED : "required",
	TABLE_HEADER_PROPERTY : "Property",
	TABLE_HEADER_REQUIRED : "Required",
	TABLE_HEADER_TYPE : "Type",
	TABLE_HEADER_DESCRIPTION : "Description"
};