cmapi.channel["map.feature.draw"].examples = [{
    "title": "Edit a feature",
    "description": "Draw a new feature on the map",
    "valid": true,
    "payload": {
        "featureId": "0001-0002-0003-0004",
        "name": "My new line",
        "overlayId": "0005-0006-0007-0008",
        "type": "line",
        "messageId": "19733f70-d0b8-11e3-9c1a-0800200c9a66"
    }
}]
