cmapi.channel["map.status.about"].examples = [{
  "title": "Send out static information about this map implementation",
  "description": "",
  "valid": true,
  "payload": {
    "version": "1.0.0",
    "type": "2-D",
    "widgetName": "Common Map Widget",
    "extensions": ["clustering", "userManipulation"]
  }
}];
