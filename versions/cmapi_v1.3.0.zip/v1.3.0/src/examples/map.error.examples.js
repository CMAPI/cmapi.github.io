cmapi.channel["map.error"].examples = [{
  "title": "Example map error",
  "description": "",
  "valid": true,
  "payload": {
    "sender": "29ff882d-4ef3-4ea2-852e-de799dd0699d",
    "type": "map.feature.hide",
    "msg": {
      "overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1",
      "featureId": "example.mapWidget.doesntExist"
    },
    "error": "No feature with id example.mapWidget.doesntExist found to hide."
  }
}];