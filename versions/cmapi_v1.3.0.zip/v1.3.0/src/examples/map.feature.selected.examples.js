cmapi.channel["map.feature.selected"].examples = [
    {
        "title": "Feature Selected Message",
        "description" : "Select a feature",
        "valid": true,
        "payload": {
            "selectedId": "example.mapWidget.1.1", 
            "selectedName": "World Trade Center", 
            "featureId": "example.mapWidget.1", 
            "overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1"
        }
    }
];



