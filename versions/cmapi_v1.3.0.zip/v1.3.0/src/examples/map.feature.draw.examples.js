cmapi.channel["map.feature.draw"].examples = [{
  "title": "Edit a feature",
  "description": "Draw a new feature on the map",
  "valid": true,
  "payload": {
    "overlayId": "mario foxtrot",
    "featureId": "broccoli yankee",
    "name": "broccoli yankee",
    "type": "line",
    "messageId": "00049622-581b-d609-d818-32f8930412e0"
  }
}];
