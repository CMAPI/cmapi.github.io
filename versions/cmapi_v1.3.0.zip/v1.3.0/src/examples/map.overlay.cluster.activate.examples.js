cmapi.channel["map.overlay.cluster.activate"].examples = [{
  "title": "Activate overlay cluster rule example",
  "description": "",
  "valid": true,
  "payload": {
    "overlayId": "BattlePlan2"
  }
}];