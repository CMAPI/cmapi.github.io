cmapi.channel["map.feature.plot.geojson"].notes = [
    "For example of GeoJSON, see map.feature.plot Example 3 (Plot GeoJSON)."
  ];