cmapi.channel["map.overlay.show"].notes = [
    "If the action to show the overlay originates within the map application\'s user interface (i.e., the map is not responding to an external message), the map SHALL send out a corresponding map.overlay.show message."
];