cmapi.channel["map.feature.edit"].notes = [
    "This is the format of the details object to be used in a map.message.complete message for feature editing.",
    "In the event that the edit is being cancelled, these fields shall contain the state of the feature prior to the map.feature.edit."
  ];