cmapi.overview["map.menu.overview"] = {
  "title": "map.menu namespace",
  "sections": [{
    "title": "Overview",
    "paragraphs": [
      "Namespace for those channels and messages related to menus"
    ]
  }]
};
