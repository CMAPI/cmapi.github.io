cmapi.overview["cmapi.runtimes.owf.overview"] = {
  "title": "OWF Specific Extensions",
  "sections": [{
    "title": "Overview",
    "paragraphs": [
      "This is for extensions that are directly and only applicable to Ozone Widget Framework (OWF) implementations."
    ]
  }]
};
