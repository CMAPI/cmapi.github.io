cmapi.overview["map.overview"] = {
  "title": "map namespace",
  "sections": [{
    "title": "Overview",
    "paragraphs": [
      "Top level namespace for a channels in the CMAPI specification."
    ]
  }]
};
