cmapi.overview["cmapi.core.channels.overview"] = {
	"title": "CMAPI Core Message Channels",
	"sections": [{
		"title": "Background",
		"paragraphs": [
			"CMAPI is a publish subscribe specifiation that defines JSON objects and the named channels over which they are to be transmitted.  Below are the channels used in the CMAPI COre.  Optional extensions to these channels and JSON messages as well as additional channels are defined in the CMAPI extensions section."
		]
	}]
};