cmapi.overview["cmapi.acknowledgements"] = {
	"sections": [{
		"title": "CMAPI Editors",
		"paragraphs": [
			"Chris Bashioum - cbashioum@mitre.org",
			"Eric Briscoe - eric.j.briscoe@gmail.com",
			"Scott Hammonds - "
		]
	},
	{
		"title": "CMAPI Contributors",
		"paragraphs": [
			"Collecting list of contributors..."
		]
	}]
};