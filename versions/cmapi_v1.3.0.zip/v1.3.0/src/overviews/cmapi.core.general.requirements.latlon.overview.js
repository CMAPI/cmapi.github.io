cmapi.overview["cmapi.core.general.requirements.latlon.overview"] = {
  "title": "Latitude and Longitude",
  "sections": [{
    "title": "",
    "paragraphs": [
      "All latitudes and longitudes are in decimal degrees. "
    ]
  }]
};
