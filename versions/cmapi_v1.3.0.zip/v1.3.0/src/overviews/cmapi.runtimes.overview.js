cmapi.overview["cmapi.runtimes.overview"] = {
  "title": "CMAPI Rutime Extensions",
  "sections": [{
    "title": "Overview",
    "paragraphs": [
      "In some cases the runtime where applications are using CMAPI allows for capabilites to leverage CMAPI data formats in unique ways.  When running in the frameworks listed below these runtime specific capbilities SHOULD be implemented according to this document to ensure compatibility within the given runtime."
    ]
  }]
};
