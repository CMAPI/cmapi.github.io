cmapi.overview["map.feature.formats.overview"] = {
  "title": "map.feature data formats",
  "sections": [{
    "title": "Overview",
    "paragraphs": [
      "This section provides amplifying detail and normative statements concerning the allowable and required formats for the feature data referenced in the map.feature namespace. It is anticipated that communities of interest (COI) will add subsections to this section for feature formats that are applicable to their COI."
    ]
  }]
};
