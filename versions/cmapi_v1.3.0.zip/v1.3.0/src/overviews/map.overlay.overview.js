cmapi.overview["map.overlay.overview"] = {
  "title": "map.overlay namespace",
  "sections": [{
    "title": "Overview",
    "paragraphs": [
      "Namespace for those messages and channels associated with creating and manipulating overlays.  Overlays can be thought of as a container for features and map data."
    ]
  }]
};
