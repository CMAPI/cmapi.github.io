cmapi.overview["map.overlay.cluster.overview"] = {
  "title": "map.overlay.cluster namespace ",
  "sections": [{
    "title": "Overview",
    "paragraphs": [
      "Namespace for map.overlay.cluster that allow control for how points within an overlay get clustered or decluttered for display on the map"
    ]
  }]
};
