cmapi.channel["map.overlay.hide"] = {
  schema: {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "map.overlay.hide",
    "properties": {
      "overlayId": {
        "type": "string"
      }
    },
    "required": []
  }
};
