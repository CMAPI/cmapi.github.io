cmapi.channel["map.overlay.cluster.deactivate"] = {
  schema: {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "map.overlay.cluster.deactivate",
    "properties": {
      "overlayId": {
        "type": "string"
      }
    },
    "required": []
  }
};
