cmapi.channel["map.view.zoom"] = {
  schema: {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "title": "map.view.zoom",
    "type": "object",
    "properties": {
      "range": {
        "type": "number"
      }
    },
    "required": ["range"]
  }
};
