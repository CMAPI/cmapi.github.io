cmapi.channel["map.feature.edit"].examples = [{
    "title": "Edit a feature",
    "description": "Edit an existing feature on the map",
    "valid": true,
    "payload": {
        "overlayId": "test-overlay-123-456",
        "featureId": "feature123-456",
        "messageId": "19733f70-d0b8-11e3-9c1a-0800200c9a66"
    }
}]
