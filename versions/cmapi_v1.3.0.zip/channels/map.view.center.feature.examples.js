cmapi.channel["map.view.center.feature"].examples = [
    {
        "title": "Center on a feature",
        "description": "Center the map on a particular feature",
        "valid": true,
        "payload": {
            "overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1",
			"featureId": "example.mapWidget.1"
        }
    }
]



