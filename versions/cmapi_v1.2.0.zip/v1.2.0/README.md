cmapi-1.3.0
===========

Schemas, decriptions, and examples for the CMAPI 1.3.0 specification

