cmapi.channel["map.view.zoom"].examples = [
    {
        "title": "Zoomto a range",
        "description": "Zoom the map to a particular range.",
        "valid": true,
        "payload": {
            "range": 100000
        }
    }
]



