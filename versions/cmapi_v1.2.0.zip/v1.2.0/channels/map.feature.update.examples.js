cmapi.channel["map.feature.update"].examples = [
    {
        "title": "Update a feature",
        "description": "",
        "valid": true,
        "payload": {
            "overlayId": "2d882141-0d9e-59d4-20bb-58e6d0460699.1", 
            "featureId": "example.mapWidget.2", 
            "name": "New Name"
        }
    }
]



